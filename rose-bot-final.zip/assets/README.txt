Put menu.jpg (or menu.png / menu.mp4 / menu.gif) here to send .menu as a picture or video.
